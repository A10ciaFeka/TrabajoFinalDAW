module.exports = {
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3305,
    database: 'dbgameboxd'
}